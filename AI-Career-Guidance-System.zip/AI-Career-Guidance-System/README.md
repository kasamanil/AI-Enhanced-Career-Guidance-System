# AI-Enhanced Career Guidance System

An end-to-end **machine learning + Flask** web app that recommends **personalized career paths** based on a user's skills and strengths. Designed for easy deployment and interview-ready explanation.

## ✨ Features
- Web form to collect user inputs (skills/abilities on a 0–10 scale)
- ML model (RandomForest) to predict a best-fit career
- Clean results page with next steps and retry flow
- Modular source code (`src/`) with training script and utilities
- Sample dataset + pre-trained model included

## 🧱 Project Structure
```
AI-Career-Guidance-System/
│── README.md
│── requirements.txt
│── app.py
│── models/
│    └── career_model.pkl
│── static/
│    └── style.css
│── templates/
│    ├── index.html
│    └── results.html
│── dataset/
│    └── careers.csv
│── src/
│    ├── preprocessing.py
│    ├── recommender.py
│    └── utils.py
```

## 🚀 Quickstart
```bash
pip install -r requirements.txt
python app.py
# visit http://127.0.0.1:5000
```

## 🧪 Train/Re-train the Model
```bash
python src/recommender.py
```
This will read `dataset/careers.csv` and save a new model to `models/career_model.pkl`.

## 🧠 How the Model Works (Interview Notes)
- We use a **RandomForestClassifier** (bagging of decision trees) because it:
  - Handles mixed feature interactions well
  - Is robust to noise and outliers
  - Provides strong baseline accuracy with minimal tuning
- Features used (in order): `prog`, `maths`, `comm`, `prob`
- Label: `career` (categorical string like "Software Developer", "Data Scientist", etc.)

**Pipeline summary:**
1. Collect user scores →
2. Convert to vector `[prog, maths, comm, prob]` →
3. Predict class with RandomForest →
4. Map prediction to human-readable career title →
5. Render result page with guidance.

## 🔒 Notes on Ethics & Bias
- Small sample datasets can encode bias; use **diverse and representative** training data.
- Avoid inferring sensitive attributes; get **informed consent** for data usage.
- Offer disclaimers: recommendations are **advisory**, not deterministic.

## 🧰 Tech Stack
- Backend: Flask
- ML: scikit-learn, pandas, numpy
- Frontend: HTML, CSS (vanilla)
- Packaging: pickle for model persistence

## 📄 License
MIT
