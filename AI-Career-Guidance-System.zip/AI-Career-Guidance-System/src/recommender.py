import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import pickle
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
data_path = BASE / "dataset" / "careers.csv"
model_path = BASE / "models" / "career_model.pkl"

df = pd.read_csv(data_path)

X = df[["prog", "maths", "comm", "prob"]]
y = df["career_idx"]  # integer classes 0..N-1

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

model = RandomForestClassifier(n_estimators=150, max_depth=None, random_state=42)
model.fit(X_train, y_train)

with open(model_path, "wb") as f:
    pickle.dump(model, f)

print("Model trained and saved to", model_path)
