# Placeholder for future preprocessing steps (scaling, encoding, etc.)
# For this simple demo, the features are already numeric in the correct range.
def preprocess(df):
    return df
