CAREER_LABELS = [
    "Software Developer",
    "Data Scientist",
    "AI/ML Specialist",
    "Cyber Security Analyst",
    "Business Analyst",
    "Project Manager",
    "Networking Engineer",
    "Database Administrator"
]
