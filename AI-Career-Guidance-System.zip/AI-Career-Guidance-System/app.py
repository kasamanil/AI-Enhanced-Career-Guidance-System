from flask import Flask, render_template, request
import pickle
import numpy as np
import os

app = Flask(__name__, template_folder="templates", static_folder="static")

MODEL_PATH = os.path.join(os.path.dirname(__file__), "models", "career_model.pkl")
with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

FEATURES = ["prog", "maths", "comm", "prob"]

CAREER_LABELS = [
    "Software Developer",
    "Data Scientist",
    "AI/ML Specialist",
    "Cyber Security Analyst",
    "Business Analyst",
    "Project Manager",
    "Networking Engineer",
    "Database Administrator"
]

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    # Ensure fixed feature order
    vector = [float(request.form.get(k, 0)) for k in FEATURES]
    X = np.array([vector])
    y_pred_idx = model.predict(X)[0]  # model predicts integer indices
    career = CAREER_LABELS[int(y_pred_idx)]
    return render_template("results.html", career=career, inputs=dict(zip(FEATURES, vector)))

if __name__ == "__main__":
    app.run(debug=True)
